package bills2u_constant;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Obj_Rep_Launch {


//    APPLICATION LAUNCH PAGE

    @FindBy(xpath = "/html/body/app-root/div/app-layout/mat-sidenav-container/mat-sidenav-content/div[1]/app-landing/div[1]/div/div[2]/div/button")
    public WebElement btnAppLogin;


}
